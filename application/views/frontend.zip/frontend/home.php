	<style>
		.ws_images a {display: none !important;}
		/*css for aside end*/
		.content_item {padding: 0 !important;}
		figure {position: relative;overflow: hidden;}
		figure figcaption span.stock-alert {
			color: #fff;
		    text-align: center;
		    padding: 3px 0;
		    position: absolute;
		    top: 25px;
		    right: -50px;
		    width: 100%;
		    max-width: 166px;
		    transform: rotate(45deg);
		    font-size: 10px;
		}

		#stock-out {background: #dc3545;}
		#stock-limit {background: #ffc107;}
		@media screen and (max-width:1200px){
			.stock-alert {	max-width: 134px;}
		}
		@media screen and (max-width:992px){
			.stock-alert {max-width: 154px;}
		}
		@media screen and (max-width:800px){
			.stock-alert {max-width: 147px;}
		}
		.slick-disabled {
			background: #888 !important;
			color: #fff !important;
			font-weight: bold !important;
		}
		.jumbotron-custom-cover{position: relative;margin-top: 10px;}

		/* style for slider play push button */
		.ws_playpause,.ws_pause{display: none;}
		.ws_images{height: 350px !important;overflow: hidden;}
		.ws_images img{display: block;height: 350px !important;width:100%;}
		.ws-title{top: 45% !important;}
		.ws-title{font-size: 40px !important;text-shadow: 1px 1px 15px rgba(0,0,0,1) !important;}
		#wowslider-container1 a.ws_prev,#wowslider-container1 a.ws_next {display: none;}
		.modal-dialog {margin-top: 14%;}

		#autoModal button.close {
			position: absolute;
			right: -6px;
			top: -9px;
			background: #fff;
			opacity: 1;
			width: 22px;
			height: 22px;
			border-radius: 50%;
		}
		@media all and (max-width:992px){
			/*#wowslider-container1 {display: none;}*/
			.ws_images {height: auto !important;}
			.ws_images img {height: auto !important;}
		}
		.bg-body-color{
		    -webkit-box-shadow: 0px 5px 4px 0px rgba(0, 0, 0, 0.1); */
            box-shadow: 0px 5px 4px 0px rgba(0, 0, 0, 0.1); 
            padding: 0 15px;
		}
	</style>
	<?php if ($adsInfo != null) { ?>
	<div class="modal fade" id="autoModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	    	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	      <img src="<?php echo site_url('public/lazy_load.png'); ?>" data-src="<?php echo $adsInfo[0]->path; ?>" class="img-responsive man_lazy">
	    </div>
	  </div>
	</div>
	<?php } ?>
	<!-- <script>
		$(document).ready(function(){
			setTimeout(function(){
		        $("#autoModal").hide();
		        $(".modal-backdrop").css('display','none');
		    }, 10000);
		});
	</script> -->
    
    <style>
    .category_header .slider-array a:first-child{width: 100px;}
    @media screen and (max-width: 768px) {
        .category_header h3{font-size: 14px;} 
        .category_header .slider-array a:first-child{width: 100px;}
        .aside-menu {display: none;}
        .mobile_hide {
            display: none;
        }
    }
    .wraping{
        position: relative;
    }
    .wraping .more_cat{
        position: absolute;
        top: 94%;
        left: 250px;
        display: inline-block;
        color: #fff;
        background: #fd6a02;
        z-index: 1;
        line-height: 16px;
        padding: 0 4px;
        border-radius: 50%;
        cursor: pointer;
    }
    .wraping{margin-left: -15px;width: 515px;overflow-y: scroll;height: 350px;}
    .aside-menu {width: 270px;}
    .aside-menu li {position: relative;}
    .aside-menu li ul{
        display: none;
        position: absolute;
        right: -80%;
        top: 0;
        z-index: 999;
        width: 80%;
    }
    .aside-menu li:hover ul {display: block;}
    .aside-menu li a {
        padding: 9px 15px !important;
        transition: all 0.3s ease-in-out;
        border-bottom: 1px solid #ddd;
    }
    .aside-menu li a:hover {
        background: rgba(254,88,40,0.9);
        color: #FFF !important;
        border-left: 3px solid #fd6a02;
        border-right: 3px solid #fd6a02;
    }
    .new-custom-submenu ul li a:hover {background: rgba(254,88,40,0.9); !important;}
    </style>
<!--    <div class="dropdown all-category">
        <a href="#" class="dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" >All Categories &nbsp;</a>
        <ul  class="dropdown-menu dropdown-menu-custom" aria-labelledby="dropdownMenu1">
        <?php //if($categories != NULL){ foreach ($categories as $key => $value) {
        //$subcategories = $this->action->read("subcategory",array("category" => $value->category)); ?>
        	<li class="new-custom-submenu">
        		<a href="<?php //echo site_url("frontend/home/singlePage?brand=".$value->category."&type=category"); ?>"><b><?php echo filter($value->category); ?></b></a>
        	    <ul>
        		<?php //if($subcategories != NULL) { foreach ($subcategories as $val) { ?>
        			<li>
        			    <a style="display:inline-block;padding-left:3px;" href="<?php //echo site_url('frontend/home/brand?cat='.$value->category.'&subcat='.$val->subcategory); ?>">
        			        <i class="fa fa-angle-right"></i><?php //echo filter($val->subcategory); ?>
        			    </a>
        			</li>
        		<?php //} } ?>
        		</ul>
        	</li>
        <?php //}  } ?>
        </ul>
    </div>-->

	<div class="container jumbotron-custom-cover">
		<div class="row">
		    <div class="col-md-3 col-sm-7 mobile_hide">
		        <div class="wraping">
		            <span class="more_cat">+</span>
    		        <ul class="aside-menu">
                    <?php if($categories != NULL){ foreach ($categories as $key => $value) {
                    $subcategories = $this->action->read("subcategory",array("category" => $value->category)); ?>
                    	<li class="new-custom-submenu">
                    		<a href="<?php echo site_url("frontend/home/singlePage?brand=".$value->category."&type=category"); ?>"><b><?php echo filter($value->category); ?></b></a>
                    	    <ul>
                    		<?php if($subcategories != NULL) { foreach ($subcategories as $val) { ?>
                    			<li>
                    			    <a style="display:inline-block;padding-left:3px;" href="<?php echo site_url('frontend/home/brand?cat='.$value->category.'&subcat='.$val->subcategory); ?>">
                    			        <i class="fa fa-angle-right"></i>&nbsp;&nbsp;<?php echo filter($val->subcategory); ?>
                    			    </a>
                    			</li>
                    		<?php } } ?>
                    		</ul>
                    	</li>
                    <?php }  } ?>
                    </ul>
                </div>
		    </div>
			<div class="col-md-9">
				<div class="row">
				<!-- Start WOWSlider.com BODY section -->

				<div id="wowslider-container1">
					<div class="ws_images">
						<ul>
							<?php foreach ($slider as $key => $value) { ?>
								<li><img class="man_lazy" src="<?php echo site_url('public/lazy_load.png'); ?>" data-src="<?php echo site_url($value->slider_path); ?>" alt="<?php //echo $value->slider_title; ?>" title="<?php //echo $value->slider_title; ?>"/></li>
							<?php } ?>
						</ul>
					</div>
					<!-- <div class="ws_bullets">
						<div>
							<a href="#"></a>
							<a href="#"></a>
							<a href="#"></a>
						</div>
					</div> -->
				</div>
				<script src="<?php echo site_url("public/slider/engine1/wowslider.js"); ?>"></script>
				<script src="<?php echo site_url("public/slider/engine1/script.js"); ?>"></script>
				<!-- End WOWSlider.com BODY section -->

				</div>
			</div>
		</div>
	</div>

	<!-- <pre><?php //print_r($products);?></pre> -->

<!-- Start Category wise Product -->
	<?php
	  if(count($products)>0) {
	  foreach ($products as $key => $product) {

	?>
	<section class="container-fluid" id="category<?php echo $key+1; ?>">
		<div class="row" style="margin: 20px 0;">
			<div class="container">
				<div class="row bg-body-color">
				<div class="">
					<div class="category_header clearfix">
						<h3 class="pull-left">
							<?php
								if($product != NULL){
									echo filter($product[0]->product_cat);
								}
							?>
						</h3>

						<div class="pull-right slider-array">
						    <a style="background: transparent;color: #111;" href="<?php echo isset($product[0]) ? site_url("frontend/home/see_more?cat=".urlencode($product[0]->product_cat)) : ''; ?>">সবগুলো দেখুন</a>
							<a class="prev_<?php echo $key+1; ?>" href="#"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
							<a class="next_<?php echo $key+1; ?>" href="#"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
						</div>
					</div>
				</div>


				<div class="row bg-body-color">
					<div class="col-md-12">
						<div class="responsive_<?php echo $key+1;?> slider">

							<?php
							if($product != NULL){
								foreach ($product as $key => $value) {
							?>
							<div class="content_item">
								<a class="contain_img" href="<?php echo site_url('frontend/home/products_details/'.$value->id); ?>">
									<figure>
										<img class="img-responsive man_lazy" src="<?php echo site_url('public/lazy_load.png'); ?>" data-src="<?php echo base_url($value->img_path); ?>" alt="Product Missing">
									</figure>
									<span>
										<p class="text-center product_name"><?php echo $value->product_name ; ?></p>
										<p style="font-size: 15px;" class="price-weight text-center">
										<?php
											if($value->sale_price==null || $value->sale_price==0){
												echo $value->regular_price." টাকা";
											}else{
												echo ($value->regular_price > 0) ? "<del style='color:#dc3545'>".$value->regular_price."টাকা</del>" : "";
												echo " &nbsp;".$value->sale_price." টাকা";
											}
										?>
										</p>
									</span>
								</a>

								<span class="border-button">
									<a
										class="btn btn-default btn-sm"
										ng-click="adjustItemFn(<?php echo $value->id; ?>)"
										data-toggle="modal" data-target=".product-pupup">
										<i class="fa fa-shopping-bag" aria-hidden="true"></i>
										এখনই কিনুন
									</a>

								</span>

							</div>
							<?php }} ?>

						</div>
					 </div>
				</div>
			</div>
			</div>
		</div>
	</section>
	<?php } } ?>
	<!-- End Categorywise Product -->
	<script>
	$(document).on('ready', function() {
		$('#myModal').modal({
		  keyboard: false
		});

		$(window).on('load',function(){
	        $('#autoModal').modal('show');
	    });

     <?php
	   if($products != NULL){
	   foreach ($products as $key => $value) {
	  ?>

	  $(".responsive_<?php echo $key+1;?>").slick({
	    prevArrow: '.category_header .slider-array .prev_<?php echo $key+1; ?>',
		nextArrow: '.category_header .slider-array .next_<?php echo $key+1; ?>',
		dots: false,
		infinite: false,
		autoplay: false,
		slidesToShow: 6,
		slidesToScroll: 6,
		accessibility: true,
		responsive: [{
		  dots: false,
		  breakpoint: 1024,
		  settings: {
		  slidesToShow: 6,
		  slidesToScroll: 2,
		  infinite: false
		}

	  }, {

		breakpoint: 700,
		settings: {
		  slidesToShow: 3,
		  slidesToScroll: 2,
		  dots: false
		}

	  },{

		dots: false,
		breakpoint: 550,
		settings: {
		  slidesToShow: 2,
		  slidesToScroll: 1
		}
	  }]
	  });

	 <?php } } ?>

	   // date piker
	    $('#datetimepicker1').datetimepicker({
	        format: 'YYYY-MM-DD'
	    });
    });
</script>



<script>
    var more_cat   = document.querySelector('.more_cat'),
        aside_menu = document.querySelector('.aside-menu');
        
    more_cat.addEventListener('click', function(){
        aside_menu.scrollIntoView(false);
    });
</script>