<div class="container-fluid">
	<div class="row about">
		<div class="col-md-offset-2 col-md-8">
			<?php echo ($faqInfo) ? $faqInfo[0]->content : ""; ?>
		</div>
	</div>
</div>
