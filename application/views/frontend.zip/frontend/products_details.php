<link rel="stylesheet" href="<?php echo site_url('public/easyzoom-master/css/easyzoom.css'); ?>" />
<style type"text/css">
	.header{
		font-weight: bold;
		color:#1AA9E4;
	}
	.price{
		font-size: 28px;
		color:#444;
		font-weight: bold;
	}

	figure {
		position: relative;
		overflow: hidden;
	}
	figure figcaption span.stock-alert {
		color: #fff;
		text-align: center;
		padding: 3px 0;
		position: absolute;
		top: 25px;
		right: -50px;
		width: 100%;
		max-width: 166px;
		transform: rotate(45deg);
		font-size: 10px;
	}

	#stock-out {
		background: #dc3545;
	}
	#stock-limit {
		background: #ffc107;
	}

	.btn-md{
		background: #eb5e00;
		color: #fff;
	}
	.btn-md:hover{
		border: 1px solid #eb5e00;
		color: #eb5e00;
	}
	/*eazy Zoom Style Start Here */
	.easyzoom {
		width: 100%;
		margin: 15px 0;
	}
	.easyzoom > a > img {
		width: 100%;
	}
	.thumbnails {overflow: auto;}
	.thumbnails li {
		float: left;
		width: 19%;
		margin-right: 5px;
	}
	.thumbnails li:nth-of-type(5) {
		margin-right: 0;
	}
	.thumbnails li a {
		display: block;
		width: 100%;
	}
	.thumbnails li a img {
		width: 100%;
		height: 80px;
	}
	.suggest-product {
	    text-align: center;
	    border: 1px solid #ddd;
	    margin-bottom: 10px;
	    display: block;
	    margin-left: -15px;
		overflow: hidden;
	}
	.suggest-product img {
		transition: 0.3s;
	}
	.suggest-product img:hover {
		-moz-transform: scale(1.1);
		-webkit-transform: scale(1.1);
		transform: scale(1.1);
	}
	.suggest-product b {
		font-size: 16px;
		padding-bottom: 5px;
		display: block;
	}
	.suggest-product span {
		display: block;
	    font-size: 16px;
	    padding-top: 8px;
	    white-space: nowrap;
    	text-overflow: ellipsis;
    	overflow: hidden;
	}
	.suggest-product img {height: 140px;}

	a:hover {
		cursor: pointer;
	}

	@media screen and (max-width: 768px){
		.hide-mobile {display: none;}
		.hide-desktop {
			display: block;
			margin-top: 10px;
		}
		.suggest-product img {
			width: 100%;
			height: auto;
		}
		.thumbnails li {
			width: 18%;
		    margin-right: 3px;
		    margin-top: 3px;
		}
		.zoom-cover {
		    background: transparent;
		    width: 380px;
		    height: 415px;
		    position: absolute;
		    top: 0;
		}
	}
	@media screen and (min-width: 768px){
		.hide-mobile {display: block;}
		.hide-desktop {display: none;}
	}
	@media screen and (min-width: 1100px){
			.product_width{
			width: 16.66%;
			height: 340px !important;
			margin: 0px !important;
			padding-left: 0px !important;
			padding-right: 0px !important;
		}
	}
	.slider{
		margin: 5px !important;
	}
	/*.product_width{
		width: 20%;
	}*/
	.content_item figure:hover img{
		-moz-transform: scale(1.07);
		-webkit-transform: scale(1.07);
		transform: scale(1.07);
	}

</style>



<script>
	var _gaq=[['_setAccount','UA-2508361-9'],['_trackPageview']];
	(function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
	g.src=('https:'==location.protocol?'//ssl':'//www')+'.google-analytics.com/ga.js';
	s.parentNode.insertBefore(g,s)}(document,'script'));
</script>

<!-- single page -->
<div class="container">
    <div class="row">

	  <?php if($product_info != NULL) { ?>
	    <div class="col-md-5">
			<!-- <div style="position: absolute; top: 0; right: 0; bottom: 0; left: 0; z-index: 999; background: rgba(2, 2, 2, .5);"></div> -->

			<div class="easyzoom easyzoom--adjacent easyzoom--with-thumbnails">
				<a href="<?php echo site_url($product_info[0]->img_path); ?>">
					<img class="man_lazy" src="<?php echo site_url('public/lazy_load.png'); ?>" data-src="<?php echo site_url($product_info[0]->img_path); ?>" alt="" width="310" height="400" style="border: 1px solid #ccc;" />
				</a>
			</div>
			<div class="zoom-cover"></div>

			<!-- img src="<?php echo site_url($product_info[0]->img_path); ?>" alt="" width="310" height="400" style="border: 1px solid #ccc;" class="hide-desktop" / -->

			<div id="qunit" style="background: #999;"></div>

		  <?php if($product_info[0]->gallery_images != NULL) { ?>
			<ul class="thumbnails">
				<li>
				    <?php if($product_info[0]->img_path != NULL){ ?>
					<a href="<?php echo site_url($product_info[0]->img_path); ?>" data-standard="<?php echo site_url($product_info[0]->img_path); ?>">
						<img  class="man_lazy" src="<?php echo site_url('public/lazy_load.png'); ?>" data-src="<?php echo site_url($product_info[0]->img_path); ?>" style="border: 1px solid #ccc; padding: 8px;" alt="" />
					</a>
				    <?php } ?>
				</li>
				<?php foreach (json_decode($product_info[0]->gallery_images) as $key => $value) {  ?>
				<li>
					<?php if($value != NULL){ ?>
					   <a href="<?php echo site_url($value); ?>" data-standard="<?php echo site_url($value); ?>">
						<img class="man_lazy" src="<?php echo site_url('public/lazy_load.png'); ?>" data-src="<?php echo site_url($value); ?>" style="border: 1px solid #ccc; padding: 8px;" alt="" />
					  </a>
					<?php } ?>
				</li>
				<?php } ?>
			</ul>
		<?php  } ?>
	   </div>



	    <div class="col-md-5">
	    	<h3 class="header"><?php echo filter($product_info[0]->product_name); ?></h3>
	    	<?php if($product_info[0]->brand != "") {?>
	    	<p style="font-weight:bold;"><?php echo filter($product_info[0]->brand);?></p>
	    	<?php } ?>
	    	<p class="text-justify"><?php echo $product_info[0]->description; ?></p>
	    	<p class="price">মূল্য:
	    		<?php
					if($product_info[0]->sale_price==null || $product_info[0]->sale_price==0){
						echo $product_info[0]->regular_price." টাকা";
					}else{
						echo ($product_info[0]->regular_price > 0) ? "<del style='color:#dc3545'>".$product_info[0]->regular_price."টাকা</del>" : "";
						echo "&nbsp;".$product_info[0]->sale_price." টাকা";
					}
				?>
	    	</p>
	    	
	    	<?php if($product_info[0]->color != NULL) { ?>
	    	<strong>
	    	    Color : <?php echo filter($product_info[0]->color) ;?>
	    	</strong>
	    	<br>
	    	<?php } ?>
	    	
	    	<?php if($product_info[0]->size != NULL) { ?>
	    	<strong>
	    	    Size : <?php echo ($product_info[0]->size) ;?>
	    	</strong><br><br>
	    	<?php } ?>

	    	<span class="border-button">
	    		<!-- btn btn-default btn-md -->
				<a class=""  ng-click="adjustItemFn(<?php echo $id; ?>)" data-toggle="modal" data-target=".product-pupup">
					<img src="<?php echo base_url('public/img/cart.png');?>" style="max-width: 188px;" alt="">
				</a>

			</span>
			<div class="sharethis-inline-share-buttons" style="margin-top: 10px; margin-bottom: 8px;"></div>
	    </div>

	    <div class="col-md-2">
		   <?php if($adsInfo != NULL){ ?>
			    <a href="<?php echo $adsInfo[0]->url; ?>" target="_blank">
					<img src="<?php echo site_url($adsInfo[0]->path); ?>"  style="margin-top: 15px;" width="160" height="600">
				</a>
		   <?php } else { ?>
	        	<!-- <img src="http://via.placeholder.com/160x600" class="img-responsive img-thumbnail" style="margin-top: 15px;" width="160" height="600"> -->
		   <?php } ?>
	    </div>

	    <div class="">
			<?php
			  if($product_info != NULL){
				  $where = array(
					  "product_cat"  => $product_info[0]->product_cat
				  );
				  
				 $moreProducts = $this->action->read_limit_rand("products",$where,"rand()",12);
			  }
			?>

			<?php if($moreProducts != NULL) { ?>

	    	<div class="col-md-12" style="margin-top: 3rem;">
	    		<h3>সম্পর্কিত পণ্য</h3>
	    		<hr>
	    	</div>
          <?php
		     foreach ($moreProducts as $key => $value) {
				 
		   ?>

		    <div class="col-md-2 product_width">
				<div class="responsive_<?php echo $key+1;?> slider" style="height: 340px;">

					<div class="content_item">
						<a class="contain_img" href="<?php echo site_url('frontend/home/products_details/'.$value->id);?>">
							<figure>
								<img class="img-responsive man_lazy" src="<?php echo site_url('public/lazy_load.png'); ?>" data-src="<?php echo base_url($value->img_path); ?>" alt="Product Missing">
							</figure>
							<span>
								<p class="text-center product_name"><?php echo $value->product_name; ?></p>
								<p style="font-size: 15px;" class="price-weight text-center">
								<?php
									if($value->sale_price==null || $value->sale_price==0){
										echo $value->regular_price." টাকা";
									}else{
										echo ($value->regular_price > 0) ? "<del style='color:#dc3545'>".$value->regular_price."টাকা</del>" : "";
										echo " &nbsp;".$value->sale_price." টাকা";
									}
								?>
								</p>
							</span>
						</a>

						<span class="border-button">
							<a
							class="btn btn-default btn-sm"
							ng-click="adjustItemFn(<?php echo $value->id; ?>)"
							data-toggle="modal" data-target=".product-pupup" >
								<i class="fa fa-shopping-bag" aria-hidden="true"></i>
								কার্ট এ যোগ করুন
							</a>

						</span>

					</div>

				</div>

			</div>


		  <?php  } } ?>
		 </div>
	<?php } else { ?>
		 <h4 class="alert alert-danger text-center">দুঃখিত,কোন পণ্য নেই! অনুগ্রহ করে আবার চেষ্টা করুন।</h4>
	<?php } ?>




</div>
</div>



	<script src="<?php echo site_url('public/easyzoom-master/dist/easyzoom.js'); ?>"></script>
	<script src="<?php echo site_url('public/easyzoom-master/src/easyzoom.js'); ?>"></script>

	<script>
		// Instantiate EasyZoom instances
		var $easyzoom = $('.easyzoom').easyZoom();

		// Setup thumbnails example
		var api1 = $easyzoom.filter('.easyzoom--with-thumbnails').data('easyZoom');

		$('.thumbnails').on('click', 'a', function(e) {
			var $this = $(this);

			e.preventDefault();

			// Use EasyZoom's `swap` method
			api1.swap($this.data('standard'), $this.attr('href'));
		});
	</script>
