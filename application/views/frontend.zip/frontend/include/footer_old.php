<?php
    $footer_info=json_decode($meta->footer,true);
    $menu_icon=json_decode($meta->menu_icon,true);
    $social_icon=json_decode($meta->social_icon,true);
    //print_r($footer_info);
 ?>

	<!-- First Footer Start here-->
	<div class="container-fluid footer-top" style="margin-top: 20px;">

		<div class="row">

			<div class="col-md-4 footer-top-left">
			    
                <a href="https://google.com" style="clear:both" target="_blank">
                    <img src="<?php echo site_url("public/ads/ads300.png");?>" style="width:300px;height:250px;"/>
                </a>

            <?php /*?>
				<figure class="footerlogo">
					<a href="<?php echo  site_url(); ?>"><img style="width: 100%; max-width: 190px;" src="<?php echo site_url($footer_info['footer_img']);?>" alt="Image not found!"></a>
				</figure>

				<p><?php echo $footer_info['l_footer_text'];?></p>

				<ul>
					<li><a class="fb" href="<?php echo $social_icon['s_facebook']; ?>" title="Facebook"><i class="fa fa-facebook"></i></a></li>

					<li><a class="tw" href="<?php echo $social_icon['s_twitter']; ?>" title="Twitter"><i class="fa fa-twitter"></i></a></li>

					<li><a class="gp" href="<?php echo $social_icon['s_gplus']; ?>" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>

					<li><a class="in" href="<?php echo $social_icon['s_pinterest']; ?>" title="Instagram"><i class="fa fa-instagram"></i></a></li>
				</ul>

            <?php */?>
			</div>

			<div class="col-md-4 footer-top-middle">
				<h2></h2>
				<table>
					<tr>
						<td><a href="http://amarshopingbd.com/admin" target="_blank" >Admin</a></td>
						<td></td>
					</tr>
					<tr>
						<td><a href="<?php echo site_url("about"); ?>">About Us</a></td>
						<td class="text-right"><a href="<?php echo site_url("faq"); ?>">FAQ</a></td>
					</tr>

					<tr>
						<td><a href="<?php echo site_url("pp"); ?>">Privacy Policy</a></td>
						<td class="text-right"><a href="<?php echo site_url("order"); ?>">How to Order</a></td>
					</tr>

					<tr>
						<td><a href="<?php echo site_url('returns'); ?>" >Return Policy</a></td>
						<td class="text-right"><a href="<?php echo site_url('delivery'); ?>">Delivery </a></td>
					</tr>

				</table>
			</div>

			<div class="col-md-4 footer-top-right">
				<h2>Contact</h2>

				<ul>
					<li><i class="fa fa-map-marker"></i> <?php echo $footer_info['addr_address']; ?> </li>
					<li><i class="fa fa-phone"></i> &nbsp; <?php echo $footer_info['addr_moblile']; ?></li>
					<li><i class="fa fa-envelope"></i> &nbsp; <?php echo $footer_info['addr_email']; ?></li>
					<li><i class="fa fa-users"></i> &nbsp; Total Visitor : <span><strong><?php echo count($total_visitor);?></strong></span></li>
         			<li><i class="fa fa-users"></i> &nbsp;  Today's Visitor : <span><strong><?php echo count($todays_visitor);?></strong></span></li>
				</ul>
			</div>

		</div>

	</div>
<!-- First Footer End here-->
<!-- Second Footer Start here-->
	<div class="container-fluid footer-bottom">
			<div class="col-sm-6 col-xs-12">
				<p class="text1">© <?php echo date('Y'); ?> Buy N Gain</p>
			</div>

			<div class="col-sm-6 col-xs-12">
				<p class="text2">Developed By: <a target="_blank" href="http://freelanceitlab.com/" style="color: rgba(255,255,255,0.5);">Freelance iT Lab</a></p>
			</div>
	</div>
<!-- Second Footer End here-->
</div>
	<script>
		$(document).ready(function(){
		  $(window).scroll(function() {
		    if ($(document).scrollTop() > 250) {
		      $(".top").css({'opacity': '1'});
		    }else {
		      $(".top").css({'opacity': '0'});
		    }
		  });

		  /*$(window).scroll(function() {
		    if ($(document).scrollTop() > 85) {
		      $(".nev-bg").addClass("nav-fix");
		    } else {
		      $(".nev-bg").removeClass('nav-fix');
		    }
		  });*/
		});
	</script>
	<script>/*
	$(function(){
		$('#menu').slicknav();
	});*/
	</script>

	 <script type="text/javascript">
	 	$(document).ready(function(){
	 		// call anchor animate function
 	    	$("a.category").anchorAnimate();

	 	});
	 	//scrolleffect with click event:
 		jQuery.fn.anchorAnimate = function (settings) {
 		    settings = jQuery.extend({speed: 800}, settings);
 		    return this.each(function () {
 		        var caller = this;
 		        $(caller).click(function (event) {
 		            event.preventDefault();
 		            var locationHref = window.location.href;
 		            var elementClick = $(caller).attr("href");

 		            var destination = $(elementClick).offset().top;
 		            $("html:not(:animated),body:not(:animated)").animate({scrollTop: destination}, settings.speed, function () {
 		                window.location.hash = elementClick;
 		            });

 		            return false;
 		        });
 		    });
 		};
	 </script>

	<!-- Change placeholder value start -->
	 <script>
	 	superplaceholder({
 			el: search_box,
 			sentences: [ 'Search by Product\'s Name or Category or Subcategory...........' ],
 			options: {
 				letterDelay: 80,
 				loop: true,
 				startOnFocus: false
 			}
 		})
 	</script>
	<!-- Change placeholder value start -->

	<script>
		/*global $ */
		$(document).ready(function() {

		  "use strict";

		  $('.menu > ul > li:has( > ul)').addClass('menu-dropdown-icon');
		  //Checks if li has sub (ul) and adds class for toggle icon - just an UI

		  $('.menu > ul > li > ul:not(:has(ul))').addClass('normal-sub');
		  //Checks if drodown menu's li elements have anothere level (ul), if not the dropdown is shown as regular dropdown, not a mega menu (thanks Luka Kladaric)

		  $(".menu > ul").before("<a href=\"#\" class=\"menu-mobile\">Menu</a>");

		  //Adds menu-mobile class (for mobile toggle menu) before the normal menu
		  //Mobile menu is hidden if width is more then 959px, but normal menu is displayed
		  //Normal menu is hidden if width is below 959px, and jquery adds mobile menu
		  //Done this way so it can be used with wordpress without any trouble

		  $(".menu > ul > li").hover(function(e) {
		    if ($(window).width() > 943) {
		      $(this).children("ul").stop(true, false).fadeToggle(150);
		      e.preventDefault();
		    }
		  });
		  //If width is more than 943px dropdowns are displayed on hover

		  $(".menu > ul > li").click(function() {
		    if ($(window).width() <= 943) {
		      $(this).children("ul").fadeToggle(150);
		    }
		  });
		  //If width is less or equal to 943px dropdowns are displayed on click (thanks Aman Jain from stackoverflow)

		  $(".menu-mobile").click(function(e) {
		    $(".menu > ul").toggleClass('show-on-mobile');
		    e.preventDefault();
		  });
		  //when clicked on mobile-menu, normal menu is shown as a list, classic rwd menu story (thanks mwl from stackoverflow)

		});
	</script>
	

</body>
</html>
