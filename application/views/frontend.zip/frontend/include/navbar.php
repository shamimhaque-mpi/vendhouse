<style>
	.buy-sell-box{min-height: 150px;}
	.show-only-mobile {display: none;}
	.menu {
	    margin-top: 18px;
	}
	 .signup_success{
		color : green;
		font-weight: bold;
		font-size: 15px
	  }
	  .login_error,.signup_error{
		  color : red;
		  font-weight: bold;
		  font-size: 15px
		}
		.new-logo img {
			padding: 0px 5px 5px 5px;
			max-height: 73px;
			margin-top: 0px;
			width: 100%;
			max-width: 190px;
			padding-left: 0;
		}
		.btn-yellow{
			background: #fd6a02;
			border: 1px solid #fd6a02;
			color: #fff;
		}
		.btn-yellow:hover{
			background: #fff;
			border: 1px solid #fd6a02;
			color: #fd6a02;
		}
		.btn-orange {
			background: #fd6a02;
			border: 1px solid #fd6a02;
			color: #fff;
		}
		.btn-orange:hover {
			background: #fff;
			color: #fd6a02;
			border: 1px solid #fd6a02;
		}
		.btn-cart {
			color: #fd6a02;
		    display: block;
		    position: relative;
		    right: 24px;
		}
		.btn-cart:hover {
			cursor: pointer;
			color: #fd6a02;
		}
		.btn-cart i {
			font-size: 32px;
		}
		.btn-cart span {
		    position: absolute;
		    left: 22px;
		    top: -4px;
		    background: #09184D;
		}
		.mega-menu {
			margin-top: 10px;
		}
		.mega-menu ul {
			list-style-type: none;
			padding: 0;
		}
		.mega-menu ul li {
			display: inline-block;
			position: relative;
		}
		.mega-menu ul li a {
			display: block;
		    background: #fff;
		    color: #000;
		    padding: 8px 18px;
		}
		.mega-menu ul li a:hover {
			background: red;
			text-decoration: none;
		}
		.mega-menu ul li div {
			display: none;
			position: absolute;
		}
		.mega-menu ul li:hover div {
			display: block;
		}
		.mega-menu ul li div {
			position: absolute;
		    left: -365px;
		    background: red;
		    padding: 15px;
		}
		.search-custom {
			margin-top: 13px;
			position: relative;
		}
		#demo {
			position: absolute;
			top: 10px;
			left: 10px;
			color: #666;
		}
		.search-custom input[type="text"] {
			padding: 8px;
		    border: 1px solid rgba(0,0,0,0.1);
		    width: 90%;
		    /*max-width: 450px;*/
		    border-top-left-radius: 4px;
		    border-bottom-left-radius: 4px;
		    transition: 0.3s;
		}
		.search-custom input[type="text"]:focus {
			outline: none;
			border: 1px solid #fd6a02;
		}
		.search-custom button {
		    padding: 8px 15px;
		    border: 1px solid #fd6a02;
		    background: #fd6a02;
		    color: #fff;
		    margin-left: -4px;
		    border-top-right-radius: 4px;
		    border-bottom-right-radius: 4px;
		}
		.menu-container {
		  width: 100%;
		  margin: 85px auto 0;
		  /*background: #e9e9e9;*/
		  /*border-top: 1px solid rgba(226,147,30,0.5);*/
		  background: #fd6a02;
		  border-bottom: 1px solid rgba(0,0,0,0.1);
		}
		.menu-container a.dropdown-toggle {
			color: #fff;
		}
		.menu-mobile {
		  display: none;
		  padding: 20px;
		}
		.menu-mobile:after {
		  content: "\f394";
		  font-family: "Ionicons";
		  font-size: 2.5rem;
		  padding: 0;
		  float: right;
		  position: relative;
		  top: 50%;
		  -webkit-transform: translateY(-25%);
		          transform: translateY(-25%);
		}
		.menu-dropdown-icon:before {
		  content: "\f489";
		  font-family: "Ionicons";
		  display: none;
		  cursor: pointer;
		  float: right;
		  padding: 1.5em 2em;
		  background: #fff;
		  color: #333;
		}
		.menu > ul {
		  margin: 0 auto;
		  width: 100%;
		  list-style: none;
		  padding: 0;
		  position: relative;
		  /* IF .menu position=relative -> ul = container width, ELSE ul = 100% width */
		  -webkit-box-sizing: border-box;
		  box-sizing: border-box;
		  padding-top: 10px;
		  /*font-family: 'solaimanlipinormal';*/
		}
		.menu > ul:before,
		.menu > ul:after {
		  content: "";
		  display: table;
		}
		.menu > ul:after {
		  clear: both;
		}
		.menu > ul > li {
		  float: left;
		  /*background: #e9e9e9;*/
		  padding: 0;
		  margin: 0;
		}
		.menu > ul > li a {
		  text-decoration: none;
		  padding: 12px 8px 8px;
		  display: block;
		  font-size: 16px;
		  color: #232F3E;
		}
		.menu > ul > li:hover {
		  /*background: #f0f0f0;*/
		}
		.menu > ul > li > ul {
		  display: none;
		  width: 100%;
		  /*background: #f0f0f0;*/
		  background: #fff;
		  padding: 20px;
		  position: absolute;
		  z-index: 0;
		  left: 0;
		  margin: 0;
		  list-style: none;
		  -webkit-box-sizing: border-box;
		  box-sizing: border-box;
		  /*padding-top: 0;*/
		}
		.menu > ul > li > ul:before,
		.menu > ul > li > ul:after {
		  content: "";
		  display: table;
		}
		.menu > ul > li > ul:after {
		  clear: both;
		}
		.menu > ul > li > ul > li {
		  margin: 0;
		  padding-bottom: 0;
		  list-style: none;
		  width: 25%;
		  background: none;
		  float: left;
		}
		.menu > ul > li > ul > li a {
		  color: #000;
		  padding: .2em 0;
		  width: 95%;
		  display: block;
		}
		.menu > ul > li > ul > li a:hover {
			color: #ffda34;
		}
		.menu > ul > li > ul > li > ul {
		  display: block;
		  padding: 0;
		  margin: 0;
		  list-style: none;
		  -webkit-box-sizing: border-box;
		  box-sizing: border-box;
		  border-left: 1px solid rgba(0,0,0,0.1);
    	  padding-left: 8px
		}
		.menu > ul > li > ul > li:nth-of-type(1) ul {
		  border: none;
		}
		.menu > ul > li > ul > li > ul:before,
		.menu > ul > li > ul > li > ul:after {
		  content: "";
		  display: table;
		}
		.menu > ul > li > ul > li > ul:after {
		  clear: both;
		}
		.menu > ul > li > ul > li > ul > li {
		  float: left;
		  width: 100%;
		  padding: 2px 0;
		  margin: 0;
		  font-size: .8em;
		}
		.menu > ul > li > ul > li > ul > li a {
		  border: 0;
		}
		.menu > ul > li > ul.normal-sub {
		  width: 300px;
		  left: auto;
		  padding: 10px 20px;
		}
		.menu > ul > li > ul.normal-sub > li {
		  width: 100%;
		}
		.menu > ul > li > ul.normal-sub > li a {
		  border: 0;
		  /*padding: 1em 0;*/
		}
		/* ––––––––––––––––––––––––––––––––––––––––––––––––––
		Mobile style's
		–––––––––––––––––––––––––––––––––––––––––––––––––– */
		@media only screen and (max-width: 959px) {
			.menu i {
				display: none;
			}
		  .menu-container {
		    width: 100%;
		    margin-top: 0;
    		background: #e9e9e9;
    		border: none;
		  }
		  .menu-mobile {
		    display: block;
		  }
		  .menu-dropdown-icon:before {
		    display: block;
		    background: #e9e9e9;
		  }
		  .menu > ul {
		    display: none;
		  }
		  .menu > ul > li {
		    width: 100%;
		    float: none;
		    display: block;
		  }
		  .menu > ul > li a {
		    padding: 1.5em;
		    width: 100%;
		    display: block;
		  }
		  .menu > ul > li > ul {
		    position: relative;
		    background: #e9e9e9;
		  }
		  .menu > ul > li > ul.normal-sub {
		    width: 100%;
		  }
		  .menu > ul > li > ul > li {
		    float: none;
		    width: 100%;
		    margin-top: 20px;
		  }
		  .menu > ul > li > ul > li:first-child {
		    margin: 0;
		  }
		  .menu > ul > li > ul > li > ul {
		    position: relative;
		  }
		  .menu > ul > li > ul > li > ul > li {
		    float: none;
		  }
		  .menu .show-on-mobile {
		    display: block;
		  }
		}
		@media screen and (max-width: 992px) {
			.search-custom input[type="text"] {
				max-width: 300px;
			}
		}
		@media screen and (max-width: 400px) {
			.search-custom input[type="text"] {
				max-width: 85%;
			}
			.new-logo img{
				width: 100%;
				padding: 0;
				margin: 0;
			}
			.btn-cart span{
				left: 150px;
			}
			.btn-cart {
				margin: 15px;
    			text-align: center;
			}
		}
		#textSlider.row {
			top: 210px;
		}
		.loginmenu{
			margin-top: 19px;
			float: right;
		}
		.loginmenu  li{
			float: left;
		}
		.modal-dialog {
			margin-top: 125px;
			max-width: 450px;
		}
		.top-contact {
			border-bottom: 1px solid rgba(0,0,0,0.1);
    		overflow: auto;
    		/*margin-bottom: 8px;*/
    		color: #232F3E;
    		background: #f2f2f2;
		}
		.top-contact ul:nth-of-type(1) {
			float: left;
    		margin-bottom: 0;
		}
		.top-contact ul:nth-of-type(1) li {
			display: inline-block;
			padding-top: 6px;
		    padding-bottom: 6px;
		}
		.top-contact ul:nth-of-type(1) li:nth-of-type(1) {
			border-right: 1px solid rgba(0,0,0,0.1);
			padding-right: 8px;
		}
		.top-contact ul:nth-of-type(1) li:nth-of-type(2) {
			padding-left: 8px;
		}
		.top-contact ul:nth-of-type(2) {
			float: right;
    		margin-bottom: 0;
		}
		.top-contact ul:nth-of-type(2) li {
			display: inline-block;
			margin-left: -4px;
		}
		.top-contact ul:nth-of-type(2) li a {
            padding: 5px 0;
            display: block;
            border-right: 1px solid rgba(0,0,0,0.1);
            padding-top: 6px;
            padding-bottom: 6px;
            color: #888;
            font-size: 15px;
            border: 0.5px solid #e6d7d7;
            margin-left: -1px;
            width: 40px;
            text-align: center;
            margin-top: -1px;
            margin-bottom: 0px;
		}
		.top-contact ul:nth-of-type(2) li a:hover{background:#fd6a02;color:#fff;}
		
		/*.top-contact ul:nth-of-type(2) li:hover {
			background: #fff;
		}
		.top-contact ul:nth-of-type(2) li:nth-of-type(1) a {
			border-left: 1px solid rgba(0,0,0,0.1);
			padding-left: 8px;
			color: #3b5999;
			transition: 0.3s;
		}
		.top-contact ul:nth-of-type(2) li:nth-of-type(2) a {
			color: #55acee;
			transition: 0.3s;
		}
		.top-contact ul:nth-of-type(2) li:nth-of-type(3) a {
			color: #dd4b39;
			transition: 0.3s;
		}
		.top-contact ul:nth-of-type(2) li:nth-of-type(4) a {
			color: #cd201f;
			transition: 0s;
		}*/

		.forgotPass{
			background-color: #222223;
			border-color: #222223;
		}
		.forgotPass:hover{
			background-color: #fff !important;
			border-color: #222223 !important;
			color: #222223 !important;
		}

		/*search box sug style start*/
		.search_relative{
			position: relative;
		}
		.Search_item{
			position: absolute;
		    top: 100%;
		    left: 0;
		    background: #fff;
		    width: calc(100% - 45px);
		    z-index: 0;
		    box-shadow: 0 8px 10px rgba(0,0,0,0.3);
		}
		.Search_item ul {
			height: auto;
			max-height: 400px;
			overflow-x: hidden;
			overflow-y: scroll;
		}
		.Search_item li{
			border-bottom:1px solid rgba(60,60,60,0.3);
		}
		.Search_item li:last-child{
			border-bottom:none;
		}
		.Search_item a{
			transition:all 0.3s ease-in-out;
			display: block;
			padding: 8px 0;
		}
		.Search_item a:hover{
			background:#ddd;
		}
		.sug_img{
			overflow: hidden;
		}
		.sug_img img{
		    display: block;
		    width: 100%;
		    max-width: 64px;
		}
		/*search box sug style end*/

		.header_title{
			display: inline-block;
			line-height: 50px;
			font-size: 1.4em;
			font-weight: bold;
			padding: 10px;
			color: #fff;
			font-family: 'bremen';
		}
		.btn-act,
		.open > .dropdown-toggle.btn-default {
			background: #FAF336;
			border: 1px solid #FAF336;
			color: #09184D;
		}
		.btn-act:hover,
		.open > .dropdown-toggle.btn-default:hover,
		.open > .dropdown-toggle.btn-default:focus {
			background: #FAF336 !important;
			border: 1px solid #FAF336;
			color: #09184D;
		}
		.dropdown-menu li {
			width: 100%;
		}

		/*category style start here*/
		.cat{
			position: relative;
		}
		.cat_nav{
			position: absolute;
			display: none;
		}
		.cat:hover .cat_nav{
			display: block;
		}
		a, a:hover, a:focus, a:visited, a:active {outline: none;}
		.aside{
			height:378px;
			width:200px;
			position: relative;
			background: #fff;
			z-index: 999;
			left:-58px;
		}
		.aside::after{
			content: '';
			display: block;
			clear: both;
		}
		.aside ul{
			list-style: none;
			position: relative;
			z-index: 999;
			height:100%;
		}
		.aside ul li{
			background:#FAF336;
			color:#fff;
		}
		.aside ul li:hover{
			background: #1E2D5D !important;
			color:#fff;
		}
		.aside ul li a{
			text-decoration: none;
			display: block;
			padding:8px 15px;
			margin-bottom:2px;
			color:#000;
			transition:all 0.3s ease-in-out;
		}
		.aside ul li:hover a{
			color:#fff;
		}
		.aside ul li a>.fa{
			float: right;
		}
		.aside>ul>li>div{
			position:absolute;
			top:0;
			left:100%;
			background:#fff;
			box-shadow: 0 0 10px rgba(60,60,60,0.5);
			padding:20px 10px;
			width: 850px;
			overflow: hidden;
		}
		.aside ul>li>div{
			display: none;
			min-height:378px;
		}
		.aside>ul>li:hover div{
			display: block;
		}
		.aside>ul>li>div>div>div>div{
			padding:0 10px;
		}
		.sub_menu_wraper>div ul{
			border-left:1px solid rgba(60,60,60,0.2);
			padding:0 20px !important;
		}
		.sub_menu_wraper:first-child div ul{
			border-left:none;
		}
		.aside>ul>li>div ul{
			/*box-shadow: 0 0 5px rgba(60,60,60,0.2);*/
			margin:0 -10px;
		}
		.aside>ul>li>div ul>li{
			float: none;
			width:100%;
			background: steelblue;
		}
		.aside>ul>li>div a{
			background:#fff;
			color:#333 !important;
			margin-bottom:0px;
			transition:all 0.3s ease-in-out;
			margin-left: -5px;
			padding: 4px 0px !important;
		}
		.aside>ul>li>div a:hover{
			color:#FAF336 !important;
		}
		.sub_heading{
			text-align: center;
			padding:10px;
			font-weight:bold;
			color:#fff !important;
			background:#09184D !important;
		}
		.product_name{
			/*white-space: nowrap;
		    overflow: hidden;
		    text-overflow: ellipsis;*/
		    padding:0 8px;
		}
		.only-sm {
			display: none;
		}

		/*category style end here*/

		@media screen and (max-width: 768px) {
			.search-custom {margin-top: 0;}
			.menu-mobile {
				background: #ccc;
				padding: 10px 20px;
			}
			.menu > ul {
				padding-top: 0;
			}
			.menu > ul > li a {
				padding: 5px 1.5rem 0;
    			color: #09184D;
			}
			.menu > ul > li:last-child a {
				padding-bottom: 5px;
			}
			
			.only-sm {
				display: block;
			    padding: 0;
			    /*line-height: 24px;*/
			    font-size: 24px;
			    margin-bottom: -11px;
			    text-align: center;
			}
			.header_title.only-sm{
			  display: none;  
			}
			.only-md {
				display: none !important;
			}
			
			.cat{display: none !important;}
			.top-contact {
				border: none;
				display: none;
			}
			.top-contact ul:nth-of-type(2) li a {
				border: none !important;
			}
			.top-contact ul:nth-of-type(1) {
			    float: none;
				text-align: center;
				border-bottom: 1px solid rgba(0,0,0,0.1);
			}
			.top-contact ul:nth-of-type(2) {
				float: none;
    			text-align: center;
			}
			.new-logo img {
				display: block;
    			margin: 0 auto;
			}
			.loginmenu {
				/*overflow: auto;*/
				margin-top: 0;
				float: none;
				margin-bottom: 0;
				text-align: center;
			}
			.loginmenu li {
				float: left;
				display: inline-block;
			}
			.loginmenu li a {
				margin: 10px 2px 4px;
			}
			.loginmenu li:nth-of-type(2) a {
			    position: relative;
			    left: 4px;
			    top: 2px;
			}
			.loginmenu li:nth-of-type(3) a {
				margin-left: 10px;
			}
			.btn-cart {
				position: static;
				margin-right: 8px;
			}
			.footer-top-right {
				padding-left: 70px;
			}
			.menu > ul > li > ul > li > ul {
				border: none;
			}
			.btn-cart span {
				left: 20px !important;
				top: 0px;
				background: #09184D;
				z-index: 999;
			}
			.Search_item {
				z-index: 999;
			}
		}

		/* badge style */
		.li-badge{
			position: relative;
		}
		.li-badge .badge{
			position: absolute;
			right: -15px;
			top: -11px;
			background: #09184D;
			color: #fff;
		}

			.signup1 {
	  			text-align:left;
	  			margin-top: 10px;
	  			float: right;
	  			margin-right: -24px;
	  		}
	  		.signup2 {
				margin-top: 10px;
				float: right;
				margin-right: -24px;
	  		}
	  		.signup3 {
				margin-top: 10px;
				float: right;
				margin-right: -2px;
	  		}
	  		.signup4 {
				margin-top: -1px;
				float: right;
	  		}
	  		.signup5 {
				float: right;
				margin-right: -12px;
	  		}

	  		@media screen and (max-width: 992px) {
	  			.sug_img {display: none;}
	  		}

	  		@media screen and (max-width: 768px) {
	  			.signup1 {
				    margin-top: 15px;
				    margin-right: -14px;
	  			}
	  			.signup2 {
	  				margin-top: 15px;
				    margin-right: -8px;
	  			}
	  			.signup3 {
					margin-top: 16px;
					margin-right: 12px;
	  			}
	  			.signup4 {
					margin-top: 6px;
					margin-right: 0px;
	  			}
	  			.signup5 {
	  				margin-right: 2px;
					margin-top: 7px;
	  			}
	  			.menu_height {
	  				height: auto !important;
	  			}
	  			.only-sm {
	  				color: #000;
    				margin-top: -10px;
	  			}
	  			.show-only-mobile {display: block;}
	  		}

	  		@media screen and (min-width: 768px) {

	  			.menu_height{
		  			height: 90px !important;
		  			padding-top: 12px !important;
		  		}

		  		.menu-container{
		  			height: 90px !important;
		  			padding-top: 37px !important;
		  		}
	  		}
	  		@media screen and (max-width: 400px){
	  		    .search-custom input[type="text"] {width: 80%;}
	  		    .logo.only-md {
			    display: block !important;
			    margin-left: 85px;
			    }
	  		}

	</style>

<?php
    $footer_info=json_decode($meta->footer,true);
    $menu_icon=json_decode($meta->menu_icon,true);
    $social_icon=json_decode($meta->social_icon,true);
 ?>



<section class="container-fluid nev-bg nav-fix" style="padding: 0;">
    
    
<?php /*    <script id="GNR54951">
    (function (i,g,b,d,c) {
        i[g]=i[g]||function(){(i[g].q=i[g].q||[]).push(arguments)};
        var s=d.createElement(b);s.async=true;s.src=c;
        var x=d.getElementsByTagName(b)[0];
        x.parentNode.insertBefore(s, x);
    })(window,'gandrad','script',document,'//content.green-red.com/lib/display.js');
    gandrad({siteid:16422,slot:54951});
</script> */ ?>


    

		    <!--<div style="width:100%;text-align:center;">	    -->
      <!--          <a href="https://google.com" style="clear:both" target="_blank">-->
      <!--              <img src="<?php //echo site_url("public/ads/ad728.gif");?>" style="width:700px;height:90px;"/>-->
      <!--          </a>-->
      <!--      </div>-->
    
	<div class="top-contact">
		<div class="container">
			<div class="">
				<ul>
					<li><i class="fa fa-phone-square"></i>  <?php echo $footer_info['addr_moblile']; ?></li>
					<li><i class="fa fa-envelope-o"> &nbsp;</i><?php echo $footer_info['addr_email']; ?></li>
				    <?php
				        $coupon = $this->action->read('coupon')[0];
				        if(!empty($coupon) && (int)$coupon->coupon_discount > 0) {
				    ?>
					<li> | <strong style="color: #fd6a02;"><i class="fa fa-ticket">&nbsp;</i><?= $coupon->coupon_no.' - '.$coupon->coupon_discount ?></strong></li>
				    <?php
				        }
				    ?>
				</ul>
				<ul>
					<li><a href="<?php echo $social_icon['s_facebook']; ?>"><i class="fa fa-facebook"></i></a></li>
					<li><a href="<?php echo $social_icon['s_twitter']; ?>"><i class="fa fa-twitter"></i></a></li>
					<li><a href="<?php echo $social_icon['s_gplus']; ?>"><i class="fa fa-google-plus"></i></a></li>
					<li><a href="<?php echo $social_icon['s_pinterest']; ?>"><i class="fa fa-youtube"></i></a></li>
				</ul>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row menu_height">
			<div class="col-sm-3 new-logo">
				<div class="row">
					<a href="<?php echo site_url(); ?>" style="display:block;width:100%;max-width: 190px;">
						<img class="logo only-md" src="<?php echo site_url($footer_info['footer_img']); ?>" class="img-responsive" alt="Size 200x60">
						<span class="header_title only-sm"><?php echo $footer_info['header_txt']; ?></span>
					</a>
				</div>
			</div>

			<div class="col-sm-6">
			    <div class="search_relative">
					<?php
					 $attr = array("class" => "search-custom");
					  echo form_open("frontend/home/search/",$attr);
					?>
						<input type="text" id="search_box"  name="search" ng-model="search_item" ng-blur="showHideFn();" ng-change="getProductInfoFn(); showHideFn();" required>

						<button>
							<i class="fa fa-search"></i>
						</button>
					<?php echo form_close(); ?>
					
			
					<!-- data list view for search start -->
					<div class="Search_item_cover">
    					<div ng-if="allSearchProductsInfo.length > 0"  class="Search_item" ng-show="active">
    						<ul>
    							<li ng-repeat="item in allSearchProductsInfo" class="clearfix">
    								<a class="clearfix" href="<?php echo site_url('frontend/home/products_details/{{ item.id}}'); ?>" target="_blank">
    
    									<div class="col-sm-2 sug_img">
    										<img ng-src="<?php echo site_url('{{ item.img_path}}');?>" alt="Missing">
    									</div>
    
    									<div class="col-sm-7 col-xs-8">
    										<b style="font-size: 14px; font-weight: normal;">{{ item.product_name | textBeautify }}</b> <br />
    										<span style="font-size: 14px; color: #aaa;">{{ item.product_cat | textBeautify }}</span>
    									</div>
    
    									<div class="col-sm-3 col-xs-4">
    										<del ng-show="item.regular_price > 0"> {{ item.regular_price }}টাকা</del>
    										<span> {{ item.sale_price }}টাকা</span>
    									</div>
    								</a>
    							</li>
    						</ul>
    					</div>
					</div>
					<!-- data list view for search end -->
				</div>
			</div>



			<div class="col-sm-3">
				<ul class="loginmenu">
				<li>
						<a href="#" class="btn btn-menu-custom" data-action="toggle" data-side="left">&#9776;</a>
					</li>
					<li>
						<a class="btn-cart" data-toggle="modal" data-target=".order-popup" ng-click="loadValueFromLocalStorage();">
							<i class="fa fa-shopping-bag" aria-hidden="true"></i>
							<span class="badge badge-success">{{ productInCart }}</span>
						</a>

					</li>

					<?php if($this->session->userdata('subscriberLoggedin') == 1){ ?>
						<li><a class="btn btn-primary btn-yellow show-only-mobile" href="<?php echo base_url('subscriber/dashboard');?>"><b>হোম</b></a></li>
						<li class="dropdown li-badge">
						  <button class="btn btn-default btn-act dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true">
						    <i class="fa fa-user"></i> আমার অ্যাকাউন্ট
							<?php if($this->session->userdata('point') > 0) { ?>
								<!-- <span title="Your Balance Point" class="badge badge-messages"><?php  echo $this->session->userdata('point'); ?></span> -->
							<?php } ?>
						    <span class="caret"></span>
						  </button>
							<ul class="dropdown-menu dropdown-menu-right">
		                        <!-- <li class="dropdown-menu-description"><a>&nbsp;</a></li> -->
		                        <li><a href="<?php echo site_url('subscriber/currentOrder');?>">বর্তমান অর্ডার</a></li>
		                        <li><a href="<?php echo site_url('subscriber/allOrder');?>">সকল অর্ডার</a></li>
		                        <li><a href="<?php echo site_url('subscriber/settings');?>">ব্যাক্তিগত তথ্য</a></li>
		                        <li><a href="<?php echo site_url('subscriber/settings/updatePassword');?>">সেটিংস</a></li>
		                        <li class="divider"></li>
		                        <li><a href="<?php echo site_url("access/subscriber/logout"); ?>">সাইন আউট</a></li>
		                    </ul>
						</li>

					<?php }elseif($this->session->userdata('srLoggedin') == 1){ ?>
						<li><a class="btn btn-primary btn-yellow show-only-mobile" href="<?php echo base_url('sr/dashboard');?>"><b>হোম</b></a></li>
						<li class="dropdown li-badge">
						  <button class="btn btn-default btn-act dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true">
						    <i class="fa fa-user"></i> আমার অ্যাকাউন্ট
						    <span class="caret"></span>
						  </button>
							<ul class="dropdown-menu dropdown-menu-right">
		                        <li><a href="<?php //echo site_url('sr/currentOrder');?>">বর্তমান অর্ডার</a></li>
		                        <li><a href="<?php //echo site_url('sr/allOrder');?>">সকল অর্ডার</a></li>
		                        <li><a href="<?php //echo site_url('sr/settings');?>">ব্যাক্তিগত তথ্য</a></li>
		                        <li><a href="<?php //echo site_url('sr/settings/updatePassword');?>">সেটিংস</a></li>
		                        <li class="divider"></li>
		                        <li><a href="<?php echo site_url("access/sr/logout"); ?>">সাইন আউট</a></li>
		                    </ul>
						</li>
					<?php }else{ ?>
						<li><a class="btn btn-primary btn-yellow show-only-mobile" href="<?php echo base_url();?>"><b>হোম</b></a></li>
						<li><a data-toggle="modal" data-target="#signin" class="btn btn-primary btn-yellow btn-blue"><b>সাইন ইন</b></a> &nbsp;</li>
						<li><a data-toggle="modal" data-target="#signup" class="btn btn-primary btn-yellow"><b>সাইন আপ</b></a></li>
				    <?php } ?>
				</ul>

			</div>
		</div>
	</div>
  </section>


<div id="signin" class="modal fade" role="dialog" ng-controller="SubscriberLoginCtrl" ng-cloak>
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">সাইন ইন</h4>
      </div>
      <div class="modal-body">
		<p class="login_error">{{ login_error }}</p>
	    <form class="form-horizontal" ng-submit="getAccessLogin();">
		  <div class="form-group">
		  	<div class="col-sm-2">
		  		<label class="row control-label" style="margin-top: 10px; float: right; margin-right: -20px;">মোবাইল</label>
		  	</div>
		    <div class="col-sm-10">
			  <p class="login_error">{{ mobile_field }}</p>
		      <input type="text" name="mobile" ng-model="mobile" class="form-control" placeholder="মোবাইল নাম্বার" required>
		    </div>
		  </div>
		  <div class="form-group">
		  	<div class="col-sm-2">
		  		<label class="control-label" style="margin-top: 10px;">পাসওয়ার্ড</label>
		  	</div>
		    <div class="col-sm-10">
			  <p class="login_error">{{ password_field }}</p>
		      <input type="password" name="password" ng-model="password" class="form-control" placeholder="পাসওয়ার্ড লিখুন" required>
		    </div>
		  </div>
		  <div class="form-group">
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-default btn-yellow">সাইন ইন</button>
		      <!--a href="<?php echo site_url('frontend/home/updatePass') ?>" class="btn btn-primary forgotPass" >Forgot Password</a-->
		    </div>
		  </div>
		</form>
      </div>
    </div>
  </div>
</div>


<div id="signup" class="modal fade" role="dialog" ng-controller="SubscriberSignupCtrl" ng-cloak>
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">সাইন আপ</h4>
        <p class="signup_error">{{ signup_warning }}</p>
		<p class="signup_success">{{ signup_success }}</p>
      </div>
      <div class="modal-body">
		
  	     <form class="form-horizontal" ng-submit="signupFn();">
		  <div class="form-group">
		  	<div class="col-xs-2">
		  		<label class="row control-label text-left signup1">নাম</label>
		  	</div>
		    <div class="col-xs-10">
			  <p class="signup_error">{{ name_field }}</p>
		      <input type="text" ng-model="name" class="form-control" placeholder="পুরো নাম লিখুন" required>
		    </div>
		  </div>
		  <div class="form-group">
		  	<div class="col-xs-2">
		  		<label class="row control-label signup2">মোবাইল</label>
		  	</div>
		    <div class="col-xs-10">
			  <p class="signup_error">{{ mobile_field }}</p>
		      <input type="text" ng-model="mobile" class="form-control" placeholder="মোবাইল নাম্বার" required>
		    </div>
		  </div>
		  <div class="form-group">
		  	<div class="col-xs-2">
		  		<label class="row control-label signup3">পাসওয়ার্ড</label>
		  	</div>
		    <div class="col-xs-10">
			  <p class="signup_error">{{ password_field }}</p>
		      <input type="password" ng-model="password" class="form-control" placeholder="পাসওয়ার্ড লিখুন" required>
		    </div>
		  </div>
		  <div class="form-group">
		  	<div class="col-xs-2">
		  		<label class="row control-label signup4">কনফার্ম</label>
		  	</div>
		    <div class="col-xs-10">
		      <input type="password" ng-model="confirm_password" class="form-control" placeholder="কনফার্ম পাসওয়ার্ড" required>
		    </div>
		  </div>
		  
		  <!--<div class="form-group">
		  	<div class="col-xs-2">
		  		<label class="row control-label signup5">এস আর</label>
		  	</div>
		  	<?php 
		  	    $getSr = $this->action->read('sr');
		  	?>
		    <div class="col-xs-10">
		      <select class="form-control" ng-model="sr" name="sr" ng-init="<?php echo $getSr[0]->name; ?>" required>
		          <?php foreach($getSr as $name){ ?>
		            <option value="<?php echo $name->name; ?>"><?php echo ucfirst($name->name); ?></option>
		          <?php } ?>
		      </select>
		    </div>
		  </div>-->
		  
		  <div class="form-group">
		  	<div class="col-xs-2">
		  		<label class="row control-label signup5">ঠিকানা</label>
		  	</div>
		    <div class="col-xs-10">
			  <p class="signup_error">{{ address_field }}</p>
		      <textarea ng-model="address" class="form-control" placeholder="বর্তমান ঠিকানা" cols="30" rows="2" required></textarea>
		    </div>
		  </div>
		  <div class="form-group">
		    <div class="col-xs-offset-2 col-xs-10">
		      <button type="submit" class="btn btn-default btn-yellow">সাইন আপ</button>
		    </div>
		  </div>
		</form>
      </div>
    </div>

  </div>
</div>

<style>
.btn-menu-custom,
.btn-menu-custom:hover {
  			font-size: 24px;
		    padding: 0;
		    box-shadow: inset 0 0 0;
		    display: none;
  		}
	.menu-new-custom .dropdown {
		margin-top: 16px;
    	font-size: 18px;
    	display: inline-block;
	}
	.menu-new-custom .dropdown .col-md-12 {
		width: 1100px;
	}
	.menu-new-custom .open .dropdown-toggle {
		text-decoration: none;
	}
	.dropdown-menu {
		padding: 0px 10px;
	}
	.dropdown-toggle {
		text-transform: uppercase;
		font-size: 14px;
	}
	a.dropdown-toggle {
	   border: none;
	   outline: none;
	   text-decoration: none;
	   padding: 6px 12px;
	   border: 2px solid transparent;
	   border-radius: 15px;
	}
	a.dropdown-toggle:hover, a.dropdown-toggle:focus{
	   border: 2px solid #fff;
	   border-radius: 15px;
	}
	
	.dropdown-menu li {position: relative;}
	.dropdown-menu li ul {display: none;}
	.dropdown-menu li:hover ul {
	    display: block;
	    position: absolute;
        width: 220px;
        background: #fd6a02;
        right: -220px;
        top: 0;
        border: 1px solid #fd6a02;
        border-left: none;
        border-top-right-radius: 4px;
        border-bottom-right-radius: 4px;
	}
	.new-custom-submenu ul {padding: 0px;}
	.new-custom-submenu ul li a {
	    display: block !important;
	    padding: 8px 15px !important;
        color: #fd6a02 !important;
        background-color: #fff;
        border-left: 3px solid transparent;
	    border-right: 3px solid transparent;
	}
	.new-custom-submenu ul li a:hover {
	    background: rgba(255,174,66,0.2);
	    color: #FFF !important;
	    border-left: 3px solid #fd6a02;
	    border-right: 3px solid #fd6a02;
	}
	.new-custom-submenu a {
	    display: block;
	    padding: 8px 15px !important;
        color: #fd6a02 !important;
        background-color: #fff;
        border-left: 3px solid transparent;
	    border-right: 3px solid transparent;
	}
	.dropdown-menu > li.new-custom-submenu > a:hover, 
	.dropdown-menu > li.new-custom-submenu > a:focus {
	    background: rgba(255,174,66,0.2);
	    color: #FFF !important;
	    border-left: 3px solid #fd6a02;
	    border-right: 3px solid #fd6a02;
	}
	
	
	.dropdown-menu-custom {
	    top: 35px;
	    padding: 0px;
	    background: #fd6a02;
	    color: #fd6a02;
        box-shadow: 0 0 8px #fd6a02;
	}
	@media screen and (max-width: 768px) {
		.menu-new-custom .dropdown .col-md-12 {width: 100%;}
		.all-category {display: block !important;}
		.menu-new-custom .dropdown {margin-top: 0px;}
		.menu {padding: 5px;}
		.dropdown-toggle {font-size: 12px; margin-left: 10px;}
		.btn-menu-custom, .btn-menu-custom:hover {
	  			font-size: 24px;
			    padding: 0;
			    box-shadow: inset 0 0 0;
			    display:block;
			    
	  		}
	}
	.errow_icon{
	    display: inline-block;
	    padding-top: 3px;
	    transform: rotate(180deg);
	    font-size: 1.2em;
	    color: #fff;
	}
</style>

<section class="container-fluid" style="background: #f4f8ef;">
	<div class="menu-container">
		<div class="container">
			<div class="row">
				<div class="menu menu-new-custom">
				   
				    <style>
				        .all-category {
				            position: relative;
				        }
				        .dropdown-menu-custom {
				            /*display: block;*/
				        }
				        .new-custom-submenu a, .new-custom-submenu ul li a {
				            color: #000 !important;
				        }
				    </style>
			  		<!--<div class="dropdown all-category">
						<a href="#" class="dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">All Categories &nbsp;</a>
				        <ul class="dropdown-menu dropdown-menu-custom" aria-labelledby="dropdownMenu1">
						    <?php //if($categories != NULL){ foreach ($categories as $key => $value) {
						    //$subcategories = $this->action->read("subcategory",array("category" => $value->category)); ?>
						    	<li class="new-custom-submenu">
						    		<a href="<?php //echo site_url("frontend/home/singlePage?brand=".$value->category."&type=category"); ?>">
						    		    <b><?php //echo filter($value->category); ?></b></a>
						    		    <ul>
            								<?php //if($subcategories != NULL) { foreach ($subcategories as $val) { ?>
            									<li>
            									    <a style="display:inline-block;padding-left:3px;" href="<?php //echo site_url('frontend/home/brand?cat='.$value->category.'&subcat='.$val->subcategory); ?>">
            									        <i class="fa fa-angle-right"></i>
            									        <?php //echo filter($val->subcategory); ?>
            									    </a>
            									</li>
            								<?php //} } ?>
            							</ul>
						    	</li>
				    	    <?php //}  } ?>
					    </ul>
					</div>-->
					<a href="<?php echo site_url(); ?>" class="dropdown-toggle">হোম</a>
				    <a href="<?php echo site_url("order"); ?>" class="dropdown-toggle">কিভাবে অর্ডার করবো</a>
				    <a href="<?php echo site_url("faq"); ?>" class="dropdown-toggle">জিজ্ঞাসা</a>
				    <a href="<?php echo site_url("about"); ?>" class="dropdown-toggle">আমাদের সম্পর্কে</a>
				</div>
			</div>
		</div>
	</div>
</section>
<style>
.sidebar.left {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: 270px;
    background: #f6f6f6;
}
.sidebars > .sidebar {
    position: absolute;
    padding: 10px;
    z-index: 999;
    margin-top: 143px;
    overflow-y: scroll;
}
.ui-state-active, .ui-state-active:active {
	border: 1px solid #c5c5c5 !important;
	outline: none !important;
	background: #ddd;
	color: #454545;
}
.ui-accordion .ui-accordion-content {
	padding: 5px 10px;
}
.ui-state-active .ui-icon {
	    background-image: url(http://code.jquery.com/ui/1.12.1/themes/base/images/ui-icons_444444_256x240.png);
}
.ui-accordion-content {height: auto !important;}
#accordion div a { line-height : 20px !important;}
#accordion div a {display: block;}
@media screen and (max-width: 768px) {
	.menu {display: none;}
	.content_item figure img {
        width: 100%;
        height: 150px;
    }
}
.ui-accordion-content a {border-bottom: 1px solid rgba(0,0,0,0.1); margin-bottom: 3px;}
.ui-accordion-content a:last-child {border-bottom: none;}
</style>

<div class="sidebars">
    <div class="sidebar left">
		<div id="accordion">
        ======================================================================
		  <?php
		      if($categories != NULL){ foreach ($categories as $key => $value) {
		      $subcategories = $this->action->read("subcategory",array("category" => $value->category));
		      
		      if(!empty($subcategories)){ ?>
    	            <h3> <?php echo filter($value->category); ?> </h3>
    	            <div>
        				 <?php if($subcategories != NULL) { foreach ($subcategories as $val) { ?>
        					 <a href="<?php echo site_url('frontend/home/brand?cat='.$value->category.'&subcat='.$val->subcategory); ?>"><?php echo filter($val->subcategory); ?></a>
        				 <?php } } ?>
        
        			 </div>
		      <?php } else { ?>
		          <h3> <?php echo filter($value->category); ?> </h3>
		          <div>
		              <a href="<?php echo site_url('frontend/home/brand?cat='.$value->category); ?>"> <?php echo filter($value->category); ?></a>
		          </div>
		     <?php  } } } ?>
		</div>
    </div>
</div>

<script>
	$( function() {
		$( "#accordion" ).accordion({
			active: false,
			collapsible: true
		});
	} );
</script>
