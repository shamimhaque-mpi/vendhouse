<style>
    .contact form {
        top: 190px;
    }
    .contact h2{color: initial;}
    .contact input[type="submit"] {
        color: #1aa9e4;
        border: 1px solid #1aa9e4;
    }
    .contact input[type="submit"]:hover {
        background: #1aa9e4;
        border: 1px solid #1aa9e4;
    }
</style>
<div class="container-fluid">
	<div class="row contact">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3623.068841782631!2d90.38700521449933!3d24.758828684101925!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x37564f20d3c88d2b%3A0x81acb8ddd8e92ffd!2sShankipara+Government+Primary+School!5e0!3m2!1sbn!2sbd!4v1473069578530" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

		<div class="contact">			
			<form>
				<h1>যোগাযোগ করুন</h1>
				<h2>পারফেক্ট অনুমানের জন্য</h2>

				<input type="text" placeholder="পুরো নাম" name="name">
				<input type="email" placeholder="ইমেইল ঠিকানা" name="email">
				<textarea name="message" placeholder="বার্তা লিখুন"></textarea>
				<input type="submit" value="সাবমিট" name="submit">
			</form>
		</div>

	</div>
</div>
